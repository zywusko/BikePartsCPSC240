/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Thorsteinn
 */
public class LoginAccountTest {
    
    public LoginAccountTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getType method, of class LoginAccount.
     */
    @Test
    public void testGetType() {
        System.out.println("getType");
        LoginAccount instance = new LoginAccount();
        String expResult = "typeholder";
        String result = instance.getType();
        assertEquals(expResult, result);

    }

    /**
     * Test of getUser method, of class LoginAccount.
     */
    @Test
    public void testGetUser() {
        System.out.println("getUser");
        LoginAccount instance = new LoginAccount();
        String expResult = "placeholder";
        String result = instance.getUser();
        assertEquals(expResult, result);

    }

    /**
     * Test of setUser method, of class LoginAccount.
     */
    @Test
    public void testSetUser() {
        System.out.println("setUser");
        String user = "notPlaceholder";
        LoginAccount instance = new LoginAccount();
        instance.setUser(user);
        assertEquals(user, instance.getUser());
    }

    /**
     * Test of getPass method, of class LoginAccount.
     */
    @Test
    public void testGetPass() {
        System.out.println("getPass");
        LoginAccount instance = new LoginAccount();
        String expResult = "passholder";
        String result = instance.getPass();
        assertEquals(expResult, result);
    }

    /**
     * Test of setPass method, of class LoginAccount.
     */
    @Test
    public void testSetPass() {
        System.out.println("setPass");
        String pass = "notPassholder";
        LoginAccount instance = new LoginAccount();
        instance.setPass(pass);
        assertEquals(pass, instance.getPass());
    }

    /**
     * Test of getFirstName method, of class LoginAccount.
     */
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        LoginAccount instance = new LoginAccount();
        String expResult = "firstholder";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
    }

    /**
     * Test of setFirstName method, of class LoginAccount.
     */
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "notFirstholder";
        LoginAccount instance = new LoginAccount();
        instance.setFirstName(firstName);
        assertEquals(firstName, instance.getFirstName());
    }

    /**
     * Test of getLastName method, of class LoginAccount.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        LoginAccount instance = new LoginAccount();
        String expResult = "lastholder";
        String result = instance.getLastName();
        assertEquals(expResult, result);
    }

    /**
     * Test of setLastName method, of class LoginAccount.
     */
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "notLastholder";
        LoginAccount instance = new LoginAccount();
        instance.setLastName(lastName);
        assertEquals(lastName, instance.getLastName());
    }

    /**
     * Test of getEmail method, of class LoginAccount.
     */
    @Test
    public void testGetEmail() {
        System.out.println("getEmail");
        LoginAccount instance = new LoginAccount();
        String expResult = "email@holder";
        String result = instance.getEmail();
        assertEquals(expResult, result);
    }

    /**
     * Test of setEmail method, of class LoginAccount.
     */
    @Test
    public void testSetEmail() {
        System.out.println("setEmail");
        String email = "not@holder";
        LoginAccount instance = new LoginAccount();
        instance.setEmail(email);
        assertEquals(email, instance.getEmail());
    }

    /**
     * Test of login method, of class LoginAccount.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        String user = "placeholder";
        String pass = "passholder";
        LoginAccount instance = new LoginAccount();
        boolean expResult = true;
        boolean result = instance.login(user, pass);
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class LoginAccount.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        LoginAccount instance = new LoginAccount();
        String expResult = "typeholder,placeholder,passholder,firstholder,lastholder,email@holder";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of compareTo method, of class LoginAccount.
     */
    @Test
    public void testCompareTo() {
        System.out.println("compareTo");
        LoginAccount account = new LoginAccount();
        LoginAccount instance = new LoginAccount();
        int expResult = 0;
        int result = instance.compareTo(account);
        assertEquals(expResult, result);
    }
    
}
