package AccountFiles;
import ProgramData.*;
import java.util.ArrayList;
import java.time.LocalDate;
import java.text.DecimalFormat;
/**
 * Class defining OfficeMan objects (office manager accounts)
 *
 * 
 * @version 12/3/2019
 */
public class OfficeMan extends LoginAccount
{

    private DecimalFormat df2 = new DecimalFormat("#.00");
    public OfficeMan(String name, String pass, String first, String last, String email, String type)
    {
        super(name, pass, first, last, email, type);
    }

    @Override   
    public String toString()
    {
        String accountDetails = (this.getType()  + ","  + this.getUser()  + ","  + this.getPass()  + ","  + this.getFirstName()  + ","  + this.getLastName() + 
                "," + this.getEmail());
        return accountDetails;
    }

    public void enoughParts (WareHouse warehouse, int margin, int increase)
    {
        ArrayList<BikePart> underMin = new ArrayList<BikePart>();
        for (int i = 0; i < warehouse.getInventory().size(); i++)
        {
            if ((warehouse.getInventory().get(i).getQuantity() - margin) <= (warehouse.getInventory().get(i).getMinQuantity()))
            {
                warehouse.getInventory().get(i).quantityUpMulti(increase);
            }
        }
    }

    public String commission(ArrayList<Invoice> invoices, String user, LocalDate startDate, LocalDate endDate)
    {
        double salary = 0;
        int found = 0;
        for (int i = 0; i < invoices.size(); i++)
        {
            if (invoices.get(i).getAccountName().equals(user))
            {
                found++;
                if((invoices.get(i).getSaleTime().isAfter(startDate)) && (invoices.get(i).getSaleTime().isBefore(endDate)))
                {
                    salary += invoices.get(i).getSaleTotal();
                }
            }
        }
        
        salary = (salary * .15);
        if(found == 0)
        {
            return "No invoice found for given username";
        }
        
        else
        {
            return "Payment due to " + user + " " + df2.format(salary);
        }
    }
    }
