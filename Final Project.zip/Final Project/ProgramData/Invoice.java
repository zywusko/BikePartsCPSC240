package ProgramData;
import AccountFiles.*;
import java.time.LocalDate;
/**
 * Class defining Invoice objects
 *
 * 
 * @version 12/3/2019
 */
public class Invoice
{

    private double saleTotal;
    private LocalDate saleTime;
    private String accountName;

    /**
     * default constructor, sets fields to placeholders.
     */
    public Invoice()
    {
        this.saleTotal = 0;
        this.saleTime = LocalDate.now();
        this.accountName = "";
    }
        
    
    /**
     * paramaterized constructor for an invoice object. these objects are only really used for calculating a sales associate's commission.
     * @param saleTotal double the total cost of a part sale invoice
     * @param saleTime LocalDate the date of a sale
     * @param accountName String the name of the user associated with this invoice
     */
    public Invoice(double saleTotal, LocalDate saleTime, String accountName)
    {
        this.saleTotal = saleTotal;
        this.saleTime = saleTime;
        this.accountName = accountName;
    }

    /**
     * getter, returns the total sale price for this invoice
     * @return double the saletotal for this invoice
     */
    public double getSaleTotal()
    {
        return this.saleTotal;
    }
    
    /**
     * setter, changes the total sale price to the given value
     * @param saleTotal double the new total sale price
     */
    public void setSaleTotal(double saleTotal)
    {
        this.saleTotal = saleTotal;
    }
    
    /**
     * getter, returns the date of this sale
     * @return LocalDate the date of sale
     */
    public LocalDate getSaleTime()
    {
        return this.saleTime;
    }
    
    /**
     * setter, changes the date of sale to the given date
     * @param saleTime LocalDate the new date of the sale
     */
    public void setSaleTime(LocalDate saleTime)
    {
        this.saleTime = saleTime;
    }
    
    /**
     * getter, returns the name of the account which generated this invoice.
     * @return String the name of the account 
     */
    public String getAccountName()
    {
        return this.accountName;
    }
    
    public String toString()
    {
        return (this.getSaleTotal() + "," + this.getSaleTime() + "," + this.getAccountName());
    }
}
