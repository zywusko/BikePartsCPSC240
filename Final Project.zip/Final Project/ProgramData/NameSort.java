package ProgramData;
import AccountFiles.*;
import java.util.Comparator;
/**
 * Used to sort BikePart objects by name
 *
 * 
 * @version (12/3/2019)
 */
public class NameSort implements Comparator<BikePart>
{
    /**
     * Used for sorting parts by name
     * @param part1 BikePart, the first part being compared
     * @param part2 BikePart, the second part being compared
     * @return int an integer representing which part comes first alphabetically.
     */
    public int compare(BikePart part1, BikePart part2)
    {
        return part1.getName().compareTo(part2.getName());
    }       
  
}
