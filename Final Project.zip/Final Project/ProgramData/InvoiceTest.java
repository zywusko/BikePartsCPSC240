/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.time.LocalDate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Thorsteinn
 */
public class InvoiceTest {
    
    public InvoiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getSaleTotal method, of class Invoice.
     */
    @Test
    public void testGetSaleTotal() {
        System.out.println("getSaleTotal");
        Invoice instance = new Invoice();
        double expResult = 0.0;
        double result = instance.getSaleTotal();
        assertEquals(expResult, result);

    }

    /**
     * Test of setSaleTotal method, of class Invoice.
     */
    @Test
    public void testSetSaleTotal() {
        System.out.println("setSaleTotal");
        double saleTotal = 0.0;
        Invoice instance = new Invoice();
        instance.setSaleTotal(saleTotal);
        assertEquals(instance.getSaleTotal(), saleTotal);
    }

    /**
     * Test of getSaleTime method, of class Invoice.
     */
    @Test
    public void testGetSaleTime() {
        System.out.println("getSaleTime");
        Invoice instance = new Invoice();
        LocalDate expResult = LocalDate.parse("2019-12-03");
        LocalDate result = instance.getSaleTime();
        assertEquals(expResult, result);

    }

    /**
     * Test of setSaleTime method, of class Invoice.
     */
    @Test
    public void testSetSaleTime() {
        System.out.println("setSaleTime");
        LocalDate saleTime = LocalDate.parse("2019-12-01");
        Invoice instance = new Invoice();
        instance.setSaleTime(saleTime);
        assertEquals(saleTime, instance.getSaleTime());
    }

    /**
     * Test of getAccountName method, of class Invoice.
     */
    @Test
    public void testGetAccountName() {
        System.out.println("getAccountName");
        Invoice instance = new Invoice(0, LocalDate.now(), "Apple");
        String expResult = "Apple";
        String result = instance.getAccountName();
        assertEquals(expResult, result);

    }

    /**
     * Test of toString method, of class Invoice.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Invoice instance = new Invoice(0, LocalDate.now(), "Apple");
        String expResult = "0.0,2019-12-03,Apple";
        String result = instance.toString();
        assertEquals(expResult, result);

    }
    
}
